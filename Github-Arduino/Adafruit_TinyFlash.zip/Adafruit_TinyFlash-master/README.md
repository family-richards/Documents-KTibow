Adafruit_TinyFlash
==================

Barebones Winbond SPI flash library for Arduino and Trinket
